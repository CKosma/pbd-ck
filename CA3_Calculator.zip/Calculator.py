# -*- coding: utf-8 -*-
"""
Created on Thu May 14 21:43:51 2020

@author: CamilaKosma
"""
from functools import reduce


class Calculator():
    
    def sum(values):
        return reduce (lambda x, y: x+y, values)
    
    def subtract(values):
        return reduce (lambda x, y: x-y, values)
    
    def multiply(values):
        return reduce (lambda x, y: x*y, values)
    
    def div(values):
        return reduce(lambda x, y: x/y, values) 
          
    def max(values):
        return reduce(lambda a,b: a if (a>b) else b, values) 
    
    def min(values):
        return reduce(lambda a,b: a if (a<b) else b, values) 
    
    def Leap_years(values):
        Leap_Years = list(filter(lambda leap_yrs: (leap_yrs%4 == 0) , values))
        return Leap_Years
    
    def is_even(values):
        return list(filter(lambda x: x%2==0, values))
    
    def squares(values):
        return [n**2 for n in values]
        
    def append_values(value1, value2):
            
        result = [(x,y) for x in value1 for y in value2]
        return result
    
    print(sum([47, 11, 42, 13]))
    print(subtract([2,4]))
    print(div([4,2]))
    print(max([47, 11, 42, 13]))
    print(min([47, 11, 42, 13]))
    print(is_even([47, 11, 42, 13]))
    print(list(squares([9])))
    print(Leap_years([2020, 2030,2026]))
    print(append_values(["hot", "cold", "mield"], ["food", "drink", "weather"]))
    
    
    
    
    
    
