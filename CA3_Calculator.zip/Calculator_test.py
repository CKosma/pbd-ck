# -*- coding: utf-8 -*-
"""
Created on Sun May 17 10:33:20 2020

@author: CamilaKosma
"""

import unittest

from Calculator import sum, subtract, multiply, div, max, min, Leap_years, squares, is_even, cube, append_values

class CalculatorTest(unittest.TestCase):
    
    def test_sum(self):
        self.assertEqual(sum([2, 2]), 4)
    
    def test_subtraction(self):
        self.assertEqual(subtract([2, 1]), 1)
    
    def test_multiply(self):
        self.assertEqual(multiply([2, 2]), 4)
    
    def test_max(self):
        self.assertEqual(max([10, 5]), 10)
    
    def test_min(self):
        self.assertEqual(min([10, 5]), 5)
    
    def test_squares(self):
        self.assertEqual(squares([10, 5]), [100, 25])
    
    def test_is_even(self):
        self.assertEqual(is_even([10, 2, 5]), [10, 2])
        
    def test_leap_year(self):
        self.assertEqual(Leap_years([2021, 2028, 2030]), [2028])  
    
    def test_append_values(self):
        self.assertEqual(append_values(['hot'], ['water']), [('hot', 'water')])



if __name__ == '__main__':
    unittest.main()