# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 20:11:51 2020

@author: CamilaKosma
"""

class Car(object):
    
    def __init__(self):
        self.__colour = ''
        self.__make = ''
        self.__mileage = 0
        self.engineSize = ''

    def getColour(self):
        return self.__colour

    def getMake(self):
        return self.__make

    def getMileage(self):
        return self.__mileage
    
    def getModel(self):
        return self.__model

    def setColour(self, colour):
        self.__colour = colour

    def setMake(self, make):
        self.__make = make

    def setMileage(self, mileage):
        self.__mileage = mileage
        
    def setModel(self, model):
        self.__model = model

    def paint(self, colour):
        self.__colour = colour
        return self.__colour
        print('Getting a paint job - new colour is: ' + colour)

    def move(self, distance):
        self.__mileage = self.__mileage + distance
        return self.__mileage
        print('Moved ' + str(distance) + 'kms')

class ElectricCar(Car):
    
    def __init__(self):
        Car.__init__(self)
        self.__numberFuelCells = 1

    def getNumberFuelCells(self):
        return self.__numberFuelCells

    def setNumberFuelCells(self, value):
        self.__numberFuelCells = value

class PetrolCar(Car):

    def __init__(self):
        Car.__init__(self)
        self.__numberCylinders = 2

    def getNumberCylinders(self):
        return self.__numberCylinders

    def setNumberCylinders(self, value):
        self.__numberCylinders = value
        
class DieselCar(Car):
    
    def __init__(self):
        Car.__init__(self)
        self.__engineSize = ''
        
    def getEngineSize(self):
        return self.__engineSize
    
    def setEngineSize(self, value):
        self.__engineSize = value

class HybridCar(Car):
    
    def __init__(self):
        Car.__init__(self)
        self.__engineSize = ''
        self.__numberFuelCells = 1

    def getengineSize(self):
        return self.__engineSize
    
    def getNumberFuelCells(self):
        return self.__numberFuelCells

    def setengineSize(self, value):
        self.__engineSize = value
        
    def setNumberFuelCells(self, value):
        self.__numberFuelCells = value
      
        
class CarFleet(object):
 
    def __init__(self):
        self.__petrol_car = []
        self.__electric_car = []
        self.__diesel_car = []
        self.__hybrid_car = []
    
    def create_current_stock(self):
        for i in range(20):
            self.__petrol_car.append(PetrolCar())
        for i in range(6):
            self.__electric_car.append(ElectricCar())
        for i in range(10):
            self.__diesel_car.append(DieselCar())
        for i in range(4):
            self.__hybrid_car.append(HybridCar())

    def getPetrolCar(self):
        return self.__petrol_car

    def getElectricCar(self):
        return self.__electric_car
    
    def getDieselCar(self):
        return self.__diesel_car
    
    def getHybridCar(self):
        return self.__hybrid_car
                  
    def checkCarsInStock(self):
        print('Number of Petrol Cars: ' + str(len(self.getPetrolCar())))
        print('Number of Electric Cars: ' + str(len(self.getElectricCar())))
        print('Number of Diesel Cars: ' + str(len(self.getDieselCar())))
        print('Number of Hybrid Cars: ' + str(len(self.getHybridCar())))

#This function rents one car per time.    
    def rentCar(self, type):
        if type == 'H':
            return self.__hybrid_car.pop()
        if type == 'D':
            return self.__diesel_car.pop()
        if type == 'E':
            return self.__electric_car.pop()
        elif type == 'P':
            return self.__petrol_car.pop()

        print('Car rented with success.')

#this function returns one car per time
    def returnCar(self, type, car):
        if type == 'H':
            self.__hybrid_car.append(car)
        if type == 'D':
            self.__diesel_car.append(car)
        if type == 'E':
            self.__electric_car.append(car)
        elif type == 'P':
            self.__petrol_car.append(car)
            
        print('Car returned with success.')


     
