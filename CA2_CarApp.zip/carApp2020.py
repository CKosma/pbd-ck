# -*- coding: utf-8 -*-
"""
Created on Mon Mar 23 20:26:51 2020

@author: CamilaKosma
"""
import csv
from car import Car, ElectricCar, PetrolCar, DieselCar, HybridCar, CarFleet

default = Car()
default.setMake('Nissan')
default.setModel('Leaf')
default.setColour('White')
default.setMileage(0)

car1 = ElectricCar()
car1.setMake('Nissan')
car1.setModel('Leaf')
car1.setColour('White')
print(car1.getNumberFuelCells())
print(car1.getMileage())

car2 = PetrolCar()
car2.setMake('Hyundai')
car2.setModel('i30')
car2.setColour('Dark Grey')
car2.setNumberCylinders(2.0)
print(car2.getMileage())

car3 = DieselCar()
car3.setMake('Ford')
car3.setModel('Fiesta')
car3.setColour('Grey')
print(car3.setEngineSize(3.5))
print(car3.getMileage())

car4 = HybridCar()
car4.setMake('Toyota')
car4.setModel('Corola')
car4.setColour('Black')
print(car4.getNumberFuelCells())
print(car4.getMileage())

rent_petrol = []
rent_electric = []
rent_diesel = []
rent_hybrid = []

f = open('dbscarrental.csv', 'r')
try:
    Lines = f.readlines() 
    for line in Lines: 
        print("Line: {}".format(line.strip()))
except:
    print('File not exist')
finally:


    dbscarrental = CarFleet()
    dbscarrental.create_current_stock()
    print('Welcome to DBS Rental')
    answer = input('Would you like to rent a car? Press R for rent a car, U to return a car or Q to quit \n').upper()
    while True:
        if answer == 'R':
            type = input('What type of car would you like to rent? P for Petrol, E for Electric, D for Diesel or H for Hybrid \n').upper()
            if type == 'P':
                rent_petrol.append(dbscarrental.rentCar(type))
            elif type == 'E':
                rent_electric.append(dbscarrental.rentCar(type))
            elif type == 'D':
                rent_diesel.append(dbscarrental.rentCar(type))
            elif type == 'H':
                rent_hybrid.append(dbscarrental.rentCar(type))
            else:
                print('Please try again using one of the options given')
        elif answer == 'U':
            type = input('What type of car would you like to return? P for Petrol, E for Electric, D for Diesel or H for Hybrid \n').upper()
            if type == 'P':
                carro = rent_petrol.pop()
                dbscarrental.returnCar(type, carro)
            elif type == 'E':
                carro = rent_electric.pop()
                dbscarrental.returnCar(type, carro)
            elif type == 'D':
                carro = rent_diesel.pop()
                dbscarrental.returnCar(type, carro)
            elif type == 'H':
                carro = rent_hybrid.pop()
                dbscarrental.returnCar(type, carro)
            else:
                print('Please try again using one of the options given')
        elif answer == 'Q':
            print('Thank you for visiting DBS Rental!')
            break;
        else:
            print('Invalid Input. Please try again.')
            
        answer = input('Would you like to rent a car? Press R for rent a car, U to return a car or Q to quit \n').upper()


f = open('dbscarrental.csv', 'w')
w = csv.writer(f, quoting=csv.QUOTE_ALL, newline = '') 
f.close()

