# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 14:41:53 2020

@author: CamilaKosma
"""

import unittest

import corona

class TestCorona(unittest.TestCase):

    def setUp(self):
        self.contents = corona.get_page_contents()

    def test_get_page(self):
        self.assertTrue(len(self.contents) > 0)

    def test_convert_to_soup(self):
        self.assertTrue(corona.convert_to_soup(self.contents) is not None)

    def test_find_all_links(self):
        soup = corona.convert_to_soup(self.contents)
        self.assertTrue(len(corona.find_all_links(soup)) > 100)

if __name__ == '__main__':
    unittest.main()