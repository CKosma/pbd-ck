# -*- coding: utf-8 -*-
"""
Created on Sun Mar 29 11:38:50 2020

@author: CamilaKosma
"""
import requests
from bs4 import BeautifulSoup

headers = {
    'authority': 'www.worldometers.info',
    'cache-control': 'max-age=0',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
    'sec-fetch-dest': 'document',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-user': '?1',
    'referer': 'https://www.google.com/',
    'accept-language': 'en-US,en;q=0.9',
    'cookie': 'fsbotchecked=true; __cfduid=d549c4e005b46838de940bc5b812f09a31585424187; _ga=GA1.2.1105649243.1585424189; _gid=GA1.2.641969931.1585424189; _fsuid=1c0aa9bc-202b-4a90-8997-0a29c0c4600a; _fsloc=?i=IE^&c=Dublin; _fs-test=^{^\\^id^\\^:^\\^13b6ee33-4d9c-4712-b716-69ffc19a3a4b^\\^,^\\^split^\\^:0.1,^\\^expiry^\\^:1586069999000,^\\^items^\\^:^[^\\^https://a.pub.network/worldometers-info/pubfig.min.js^\\^,^\\^https://a.pub.network/worldometers-info/ab_test/846ddb0a-b7a7-4ed3-bbd7-47c8eb6d5429/pubfig.min.js^\\^^],^\\^selection^\\^:^\\^https://a.pub.network/worldometers-info/ab_test/846ddb0a-b7a7-4ed3-bbd7-47c8eb6d5429/pubfig.min.js^\\^^}; __beaconTrackerID=7yw0hh4ah; __qca=P0-1445695593-1585424190897; __gads=ID=865c9c55f1271cdc:T=1585424191:S=ALNI_MaBoqPOHIbUZl4h0b8Khgl7Mx8vUQ; cookieconsent_status=dismiss; __atuvc=2^%^7C13; __atssc=google^%^3B2',
}


def get_page_contents():
    response = requests.get('https://www.worldometers.info/coronavirus/', headers=headers)
    return response.content

def convert_to_soup(content):
    soup = BeautifulSoup(response.content, 'html.parser')
    return soup.prettify()


def process_data(soup):
    print('Country, Total Cases, New Cases, Total Deaths, New Deaths, Total Rec, Active, Serious/Critical, Total Cases/1M pop, Total Deaths/1M pop, Total Tests, Tests/1M pop', end='')


    cells = soup.find_all('td')
    for cell in cells:
        for content in cell.contents:
            value = str(cell.contents).strip('[]').replace('\n', '').replace("'",'')
            if len(value) < 1:
                print('""', end=',')
            elif value[0].lower() in 'abcdefghijklmnopqrstuvwxyz<':
                print('\n' + cell.text, end=',')
            else:
                print('""' + value + '""', end=',')


def find_all_links(soup):
    links = soup.find_all('a')
    for link in links:
       print(link)
    return links

def main():
    contents = get_page_contents()
    soup = convert_to_soup(contents)
    #print(soup.prettify())
    process_data(soup)

if __name__ == '__main__':
    main()




